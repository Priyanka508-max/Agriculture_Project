import React from "react";

import PageTitle from "./PageTitle";
import BlogPosts2Section from "./BlogPost2Section";
import CallToAction from "../Components/Home/CallToAction";


const Blog = () => {
    return (
        <main className="blog-page">
            <PageTitle />
            <BlogPosts2Section></BlogPosts2Section>
            <CallToAction></CallToAction>
        </main>
    );
};

export default Blog;
