import React from 'react';

const PageTitle = () => {
    return (
        <div
            className="page-title dark-background"
            data-aos="fade"
            style={{ backgroundImage: 'url(img/page-title-bg.webp)' }}
        >
            <div className="container position-relative">
                <h1>Blog</h1>
                <p>
                    Home
                    <span> / </span>
                    Blog
                </p>
                <nav className="breadcrumbs">
                    <ol>
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li className="current">Blog</li>
                    </ol>
                </nav>
            </div>
        </div>
    );
};

export default PageTitle;
