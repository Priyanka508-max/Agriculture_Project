import React from 'react';

// A reusable BlogPost component
const BlogPost = ({ image, date, author, category, title, link }) => {
    return (
        <div className="col-lg-4">
            <article className="position-relative h-100">
                <div className="post-img position-relative overflow-hidden">
                    <img src={image} className="img-fluid" alt={title} />
                </div>

                <div className="meta d-flex align-items-end">
                    <span className="post-date"><span>{date.day}</span>{date.month}</span>
                    <div className="d-flex align-items-center">
                        <i className="bi bi-person"></i> <span className="ps-2">{author}</span>
                    </div>
                    <span className="px-3 text-black-50">/</span>
                    <div className="d-flex align-items-center">
                        <i className="bi bi-folder2"></i> <span className="ps-2">{category}</span>
                    </div>
                </div>

                <div className="post-content d-flex flex-column">
                    <h3 className="post-title">{title}</h3>
                    <a href={link} className="readmore stretched-link">
                        <span>Read More</span>
                        <i className="bi bi-arrow-right"></i>
                    </a>
                </div>
            </article>
        </div>
    );
};

// Main BlogPosts2Section component
const BlogPosts2Section = () => {
    const posts = [
        {
            image: 'img/blog/blog-1.jpg',
            date: { day: '12', month: 'December' },
            author: 'John Doe',
            category: 'Politics',
            title: 'Dolorum optio tempore voluptas dignissimos',
            link: 'blog-details.html',
        },
        {
            image: 'img/blog/blog-2.jpg',
            date: { day: '19', month: 'March' },
            author: 'Julia Parker',
            category: 'Economics',
            title: 'Nisi magni odit consequatur autem nulla dolorem',
            link: 'blog-details.html',
        },
        {
            image: 'img/blog/blog-3.jpg',
            date: { day: '24', month: 'June' },
            author: 'Maria Doe',
            category: 'Sports',
            title: 'Possimus soluta ut id suscipit ea ut.',
            link: 'blog-details.html',
        },
        {
            image: 'img/blog/blog-4.jpg',
            date: { day: '05', month: 'August' },
            author: 'Maria Doe',
            category: 'Sports',
            title: 'Non rem rerum nam cum quo minus explicabo.',
            link: 'blog-details.html',
        },
        {
            image: 'img/blog/blog-5.jpg',
            date: { day: '17', month: 'September' },
            author: 'John Parker',
            category: 'Politics',
            title: 'Accusamus quaerat aliquam qui debitis facilis.',
            link: 'blog-details.html',
        },
        {
            image: 'img/blog/blog-6.jpg',
            date: { day: '07', month: 'December' },
            author: 'Julia White',
            category: 'Economics',
            title: 'Distinctio provident quibusdam numquam aperiam aut',
            link: 'blog-details.html',
        },
    ];

    return (
        <section id="blog-posts-2" className="blog-posts-2 section">
            <div className="container">
                <div className="row gy-4">
                    {posts.map((post, index) => (
                        <BlogPost
                            key={index}
                            image={post.image}
                            date={post.date}
                            author={post.author}
                            category={post.category}
                            title={post.title}
                            link={post.link}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default BlogPosts2Section;
