import React from "react";
import PageTitle from "./PageTitle";
import ContactSection from "./ContactSection";



const Contact = () => {
    return (
        <main className="contact-page">
            <PageTitle></PageTitle>
            <ContactSection></ContactSection>
        </main>
    );
};

export default Contact;
