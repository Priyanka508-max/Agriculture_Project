import React from 'react';

function ContactSection() {
    return (
        <section id="call-to-action" className="call-to-action section light-background">
            <div className="content">
                <div className="container">
                    <div className="row">
                        {/* Contact Information */}
                        <div className="info-box">
                            <h3>Get in touch</h3>
                            <p className="description">
                                Et id eius voluptates atque nihil voluptatem enim in tempore minima <br />
                                sit ad mollitia commodi minus.
                            </p>
                            <div className="info">
                                <p><strong>Location:</strong> A108 Adam Street, New York, NY 535022</p>
                                <p><strong>Email:</strong> info@example.com</p>
                                <p><strong>Call:</strong> +1 5589 55488 55</p>
                            </div>
                        </div>

                        {/* Contact Form */}
                        <div className="form-container">
                            <form className="php-email-form">
                                {/* Row for Name and Email */}
                                <div className="form-row">
                                    <input type="text" className="form-control" placeholder="Name" />
                                    <input type="email" className="form-control" placeholder="Email" />
                                </div>

                                {/* Full-width Subject Field */}
                                <input type="text" className="form-control full-width" placeholder="Subject" />

                                {/* Full-width Message Field */}
                                <textarea className="form-control full-width" rows="5" placeholder="Message"></textarea>

                                {/* Submit Button */}
                                <button type="submit" className="btn-submit">
                                    Send Message
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    );
}

export default ContactSection;
