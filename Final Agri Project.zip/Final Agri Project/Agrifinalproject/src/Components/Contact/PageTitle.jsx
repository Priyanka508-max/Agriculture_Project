import React from 'react';

const PageTitle = () => {
    return (
        <div
            className="page-title dark-background"
            data-aos="fade"
            style={{ backgroundImage: 'url(assets/img/page-title-bg.webp)' }}
        >
            <div className="container position-relative">
                <h1>Contact</h1>
                <p>
                    Home
                    /
                    Contact
                </p>
                <nav className="breadcrumbs">
                    <ol>
                        <li><a href="index.html">Home</a></li>
                        <li className="current">Contact</li>
                    </ol>
                </nav>
            </div>
        </div>
    );
};

export default PageTitle;
