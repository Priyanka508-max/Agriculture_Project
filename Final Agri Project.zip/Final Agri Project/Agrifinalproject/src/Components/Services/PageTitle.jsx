import React from 'react';

function PageTitle() {
    return (
        <div>
            <div
                className="page-title dark-background"
                data-aos="fade"
                style={{ backgroundImage: "url('img/page-title-bg.webp')" }}
            >
                <div className="container position-relative">
                    <h1>Services</h1>
                    <p>Home / Services</p>
                    <nav className="breadcrumbs">
                        <ol>
                            <li><a href="index.html">Home</a></li>
                            <li className="current">Services</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    );
}

export default PageTitle;
