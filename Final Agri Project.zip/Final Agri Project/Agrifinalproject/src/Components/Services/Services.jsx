import React from 'react'
import PageTitle from './PageTitle'
import ServicesSection from '../Home/ServicesSection'
import AboutSection from '../Home/AboutSection'
import TestimonialSection from '../Home/TestimonialSection'

function Services() {
    return (
        <div>
            <PageTitle></PageTitle>
            <ServicesSection></ServicesSection>
            <AboutSection></AboutSection>
            <TestimonialSection></TestimonialSection>
        </div>
    )
}

export default Services
