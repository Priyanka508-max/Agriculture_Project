import React from "react";

const heroItems = [
    {
        imgSrc: "img\hero_1.jpg",
        title: "Farming is the best solution for world starvation",
        description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    },
    {
        imgSrc: "img\hero_2.jpg",
        title: "Organic vegetables are good for health",
        description:
            "Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus.",
    },
    {
        imgSrc: "img\hero_3.jpg",
        title: "Providing Fresh Produce Every Single Day",
        description:
            "Beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.",
    },
    {
        imgSrc: "img\hero_4.jpg",
        title: "Farming as a Passion",
        description:
            "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius.",
    },
    {
        imgSrc: "img\hero_5.jpg",
        title: "Good Food For All",
        description:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    },
];

const HeroSection = () => {
    return (
        <section id="hero" className="hero section dark-background">
            <div
                id="hero-carousel"
                className="carousel slide carousel-fade"
                data-bs-ride="carousel"
                data-bs-interval="5000"
            >
                <div className="carousel-inner">
                    {heroItems.map((item, index) => (
                        <div
                            key={index}
                            className={`carousel-item ${index === 0 ? "active" : ""}`}
                        >
                            <img src={item.imgSrc} alt={`Slide ${index + 1}`} className="d-block w-100" />
                            <div className="carousel-container">
                                <h2>{item.title}</h2>
                                <p>{item.description}</p>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Carousel Controls */}
                <a
                    className="carousel-control-prev"
                    href="#hero-carousel"
                    role="button"
                    data-bs-slide="prev"
                >
                    <span
                        className="carousel-control-prev-icon bi bi-chevron-left"
                        aria-hidden="true"
                    ></span>
                </a>
                <a
                    className="carousel-control-next"
                    href="#hero-carousel"
                    role="button"
                    data-bs-slide="next"
                >
                    <span
                        className="carousel-control-next-icon bi bi-chevron-right"
                        aria-hidden="true"
                    ></span>
                </a>
            </div>
        </section>
    );
};

export default HeroSection;
