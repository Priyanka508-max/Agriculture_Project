import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './TestimonialSection.css';

function TestimonialSection() {
    return (
        <section className="testimonials-12 testimonials section" id="testimonials">
            <div className="container text-center">
                {/* Section Title */}
                <div className="section-title mb-5" data-aos="fade-up">
                    <h2 className="text-uppercase">Testimonials</h2>
                    <p className="subtitle">Necessitatibus eius consequatur</p>
                </div>

                {/* Testimonials Grid */}
                <div className="row">
                    <div className="col-md-6 mb-4">
                        <div className="testimonial text-center">
                            <img src="img\testimonials\testimonials-1.jpg" alt="Testimonial author" className="rounded-circle mb-3" width="100" />
                            <blockquote>
                                <p>
                                    “Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident deleniti iusto molestias, dolore vel fugiat ab placeat ea?”
                                </p>
                            </blockquote>
                            <p className="client-name font-weight-bold text-success">James Smith</p>
                        </div>
                    </div>
                    <div className="col-md-6 mb-4">
                        <div className="testimonial text-center">
                            <img src="img\testimonials\testimonials-2.jpg" alt="Testimonial author" className="rounded-circle mb-3" width="100" />
                            <blockquote>
                                <p>
                                    “Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident deleniti iusto molestias, dolore vel fugiat ab placeat ea?”
                                </p>
                            </blockquote>
                            <p className="client-name font-weight-bold text-success">Kate Smith</p>
                        </div>
                    </div>
                    <div className="col-md-6 mb-4">
                        <div className="testimonial text-center">
                            <img src="img\testimonials\testimonials-3.jpg" alt="Testimonial author" className="rounded-circle mb-3" width="100" />
                            <blockquote>
                                <p>
                                    “Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident deleniti iusto molestias, dolore vel fugiat ab placeat ea?”
                                </p>
                            </blockquote>
                            <p className="client-name font-weight-bold text-success">Claire Anderson</p>
                        </div>
                    </div>
                    <div className="col-md-6 mb-4">
                        <div className="testimonial text-center">
                            <img src="img\testimonials\testimonials-4.jpg" alt="Testimonial author" className="rounded-circle mb-3" width="100" />
                            <blockquote>
                                <p>
                                    “Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident deleniti iusto molestias, dolore vel fugiat ab placeat ea?”
                                </p>
                            </blockquote>
                            <p className="client-name font-weight-bold text-success">Dan Smith</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default TestimonialSection;
