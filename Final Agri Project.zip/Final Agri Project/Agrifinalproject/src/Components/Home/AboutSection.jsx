import React from 'react';

function AboutSection() {
    return (
        <section id="about" className="about section">
            <div className="content">
                <div className="container">
                    <div className="row">
                        {/* Image Section */}
                        <div className="col-lg-6 mb-4 mb-lg-0">
                            <img
                                src="img/img_long_5.jpg"
                                alt="Agriculture Field"
                                className="img-fluid img-overlap"
                                data-aos="zoom-out"
                            />
                        </div>

                        {/* Content Section */}
                        <div className="col-lg-5 ml-auto" data-aos="fade-up" data-aos-delay="100">
                            <h3 className="content-subtitle text-white opacity-50">Why Choose Us</h3>
                            <h2 className="content-title mb-4">
                                More than <strong>50 years of experience</strong> in the agriculture industry
                            </h2>
                            <p className="opacity-50">
                                Reprehenderit, odio laboriosam? Blanditiis quae ullam quasi illum minima nostrum
                                perspiciatis error consequatur sit nulla.
                            </p>

                            <div className="row my-5">
                                <div className="col-lg-12 d-flex align-items-start mb-4">
                                    <i className="bi bi-cloud-rain me-4 display-6"></i>
                                    <div>
                                        <h4 className="m-0 h5 text-white">Plants need rain</h4>
                                        <p className="text-white opacity-50">Lorem ipsum dolor sit amet.</p>
                                    </div>
                                </div>
                                <div className="col-lg-12 d-flex align-items-start mb-4">
                                    <i className="bi bi-heart me-4 display-6"></i>
                                    <div>
                                        <h4 className="m-0 h5 text-white">Love organic foods</h4>
                                        <p className="text-white opacity-50">Lorem ipsum dolor sit amet.</p>
                                    </div>
                                </div>
                                <div className="col-lg-12 d-flex align-items-start">
                                    <i className="bi bi-shop me-4 display-6"></i>
                                    <div>
                                        <h4 className="m-0 h5 text-white">Sell veggies</h4>
                                        <p className="text-white opacity-50">Lorem ipsum dolor sit amet.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default AboutSection;
