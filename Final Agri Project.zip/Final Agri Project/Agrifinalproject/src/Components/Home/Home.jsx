import React from "react";
import HeroSection from "./HeroSection";
import ServicesSection from "./ServicesSection";
import AboutSection from "./AboutSection";
import About3Section from "./About3Section";
import TestimonialSection from "./TestimonialSection";
import RecentPosts from "./RecentPosts"; // Import the component
import CallToAction from "./CallToAction";
import "./RecentPosts.css"; // Import the CSS file without assigning it to a variable name

const Home = () => {
    return (
        <main className="home-page">
            <HeroSection />
            <ServicesSection />
            <AboutSection />
            <About3Section />
            <TestimonialSection />
            <RecentPosts />
            <CallToAction />
        </main>
    );
};

export default Home;
