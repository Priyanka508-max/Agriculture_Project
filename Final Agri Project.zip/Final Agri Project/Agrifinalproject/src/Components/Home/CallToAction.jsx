import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './CallToAction.css'; // Optional: Add your custom styles here

function CallToAction() {
    return (
        <section id="call-to-action" className="call-to-action section light-background">
            <div className="content">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <h3>Subscribe To Our Newsletter</h3>
                            <p className="opacity-50">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                Nesciunt, reprehenderit!
                            </p>
                        </div>
                        <div className="col-lg-6">
                            <form action="forms/newsletter.php" className="form-subscribe php-email-form">
                                <div className="form-group d-flex align-items-stretch">
                                    <input
                                        type="email"
                                        name="email"
                                        className="form-control h-100"
                                        placeholder="Enter your e-mail"
                                    />
                                    <input
                                        type="submit"
                                        className="btn btn-secondary px-4"
                                        value="Subscribe"
                                    />
                                </div>
                                <div className="loading">Loading</div>
                                <div className="error-message"></div>
                                <div className="sent-message">
                                    Your subscription request has been sent. Thank you!
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default CallToAction;
