import React from 'react';

const TeamSection = () => {
    return (
        <section className="team-15 team section" id="team">
            {/* Section Title */}
            <div className="container section-title" data-aos="fade-up">
                <h2>Team</h2>
                <p>Necessitatibus eius consequatur</p>
            </div>

            <div className="content">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 col-md-6 mb-4">
                            <div className="person">
                                <figure>
                                    <img
                                        src="img\team\team-1.jpg"
                                        alt="Joshua Stefan"
                                        className="img-fluid"
                                    />
                                    <div className="social">
                                        <a href="#">
                                            <span className="bi bi-facebook"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-twitter-x"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-linkedin"></span>
                                        </a>
                                    </div>
                                </figure>
                                <div className="person-contents">
                                    <h3>Joshua Stefan</h3>
                                    <span className="position">Farmer</span>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-3 col-md-6 mb-4">
                            <div className="person">
                                <figure>
                                    <img
                                        src="img\team\team-2.jpg"
                                        alt="Sheena Anderson"
                                        className="img-fluid"
                                    />
                                    <div className="social">
                                        <a href="#">
                                            <span className="bi bi-facebook"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-twitter-x"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-linkedin"></span>
                                        </a>
                                    </div>
                                </figure>
                                <div className="person-contents">
                                    <h3>Sheena Anderson</h3>
                                    <span className="position">Marketing</span>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-3 col-md-6 mb-4">
                            <div className="person">
                                <figure>
                                    <img
                                        src="img\team\team-3.jpg"
                                        alt="Evan Smith"
                                        className="img-fluid"
                                    />
                                    <div className="social">
                                        <a href="#">
                                            <span className="bi bi-facebook"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-twitter-x"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-linkedin"></span>
                                        </a>
                                    </div>
                                </figure>
                                <div className="person-contents">
                                    <h3>Evan Smith</h3>
                                    <span className="position">Content</span>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-3 col-md-6 mb-4">
                            <div className="person">
                                <figure>
                                    <img
                                        src="img\team\team-1.jpg"
                                        alt="Kaylie Jones"
                                        className="img-fluid"
                                    />
                                    <div className="social">
                                        <a href="#">
                                            <span className="bi bi-facebook"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-twitter-x"></span>
                                        </a>
                                        <a href="#">
                                            <span className="bi bi-linkedin"></span>
                                        </a>
                                    </div>
                                </figure>
                                <div className="person-contents">
                                    <h3>Kaylie Jones</h3>
                                    <span className="position">Accountant</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default TeamSection;
