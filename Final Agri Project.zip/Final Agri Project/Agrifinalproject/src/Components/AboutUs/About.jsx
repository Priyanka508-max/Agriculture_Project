import React from "react";

// Import components for the About Us page sections
import PageTitle from "./PageTitle";
import About3Section from "./About3Section";
import CallToAction from "../Home/CallToAction";
import TeamSection from "./TeamSection";
import ServicesSection from "../Home/ServicesSection";
// Import ServicesSection if it exists

const About = () => {
    return (
        <main className="about-page">
            <PageTitle />
            <About3Section />
            <TeamSection />
            <ServicesSection></ServicesSection>
            <CallToAction />
        </main>
    );
};

export default About;
