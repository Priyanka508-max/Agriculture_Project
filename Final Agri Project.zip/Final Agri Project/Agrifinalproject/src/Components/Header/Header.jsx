import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isDeepDropdownOpen, setIsDeepDropdownOpen] = useState(false);

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const toggleDeepDropdown = () => {
        setIsDeepDropdownOpen(!isDeepDropdownOpen);
    };

    return (
        <header id="header" className="header d-flex align-items-center position-relative">
            <div className="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">
                <a href="/" className="logo d-flex align-items-center">
                    <img src="img/logo.png" alt="AgriCulture" />
                </a>

                <nav id="navmenu" className="navmenu">
                    <ul>
                        <li className="home"><Link to="/" className="active">Home</Link></li>
                        <li><Link to="/about-us">About Us</Link></li>
                        <li><Link to="/services">Our Services</Link></li>
                        <li><Link to="/testimonials">Testimonials</Link></li>
                        <li><Link to="/blog">Blog</Link></li>

                        <li className="dropdown">
                            <a href="#" onClick={toggleDropdown}>
                                <span>Dropdown</span>
                                <i className={`bi bi-chevron-down toggle-dropdown ${isDropdownOpen ? 'active' : ''}`}></i>
                            </a>
                            {isDropdownOpen && (
                                <ul>
                                    <li><Link to="#">Dropdown 1</Link></li>
                                    <li className="dropdown">
                                        <a href="#" onClick={toggleDeepDropdown}>
                                            <span>Deep Dropdown</span>
                                            <i className={`bi bi-chevron-down toggle-dropdown ${isDeepDropdownOpen ? 'active' : ''}`}></i>
                                        </a>
                                        {isDeepDropdownOpen && (
                                            <ul>
                                                <li><Link to="#">Deep Dropdown 1</Link></li>
                                                <li><Link to="#">Deep Dropdown 2</Link></li>
                                                <li><Link to="#">Deep Dropdown 3</Link></li>
                                                <li><Link to="#">Deep Dropdown 4</Link></li>
                                                <li><Link to="#">Deep Dropdown 5</Link></li>
                                            </ul>
                                        )}
                                    </li>
                                    <li><Link to="#">Dropdown 2</Link></li>
                                    <li><Link to="#">Dropdown 3</Link></li>
                                    <li><Link to="#">Dropdown 4</Link></li>
                                </ul>
                            )}
                        </li>

                        <li><Link to="/contact">Contact</Link></li>
                    </ul>

                    <i className="mobile-nav-toggle d-xl-none bi bi-list"></i>
                </nav>
            </div>
        </header>
    );
};

export default Header;
