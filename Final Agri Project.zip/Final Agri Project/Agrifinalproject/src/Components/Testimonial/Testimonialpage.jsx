import React from 'react';
import PageTitle from './PageTitle';
import TestimonialSection from '../Home/TestimonialSection';
import CallToAction from '../Home/CallToAction';


const TestimonialPage = () => {
    return (
        <main className="testimonial-page">
            <PageTitle />
            <TestimonialSection />
            <CallToAction />
        </main>
    );
};

export default TestimonialPage;
