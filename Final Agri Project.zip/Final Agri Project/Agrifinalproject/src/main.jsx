import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Layout from './Layout.jsx'

import Home from './Components/Home/Home.jsx'
import Services from './Components/Services/Services.jsx'
import Blog from './Blog/Blog.jsx'
import Contact from './Components/Contact/Contact.jsx'
import About from './Components/AboutUs/About.jsx'
import TestimonialPage from './Components/Testimonial/Testimonialpage.jsx'
const router = createBrowserRouter([{
  path: '/',
  element: <Layout></Layout>,
  children: [
    {
      path: "",
      element: <Home></Home>
    },
    {
      path: 'about-us', // Ensure this matches the URL you're trying to access
      element: <About></About>
    },
    {
      path: "services",
      element: <Services></Services>

    },
    {
      path: 'Testimonial',
      element: <TestimonialPage></TestimonialPage>
    },
    {
      path: "Blog",
      element: <Blog></Blog>

    },
    {
      path: "contact",
      element: <Contact></Contact>

    }
  ]
}])
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router}></RouterProvider>
    <App />
  </StrictMode>,
)
